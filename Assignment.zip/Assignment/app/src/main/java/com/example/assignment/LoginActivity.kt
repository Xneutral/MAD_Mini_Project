package com.example.assignment

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.*
import android.view.*
import android.widget.*
import com.google.firebase.auth.FirebaseAuth

class LoginActivity : AppCompatActivity() {
    private lateinit var email:EditText
    private lateinit var pass:EditText
    private lateinit var progressBar: ProgressBar
    private lateinit var fAuth: FirebaseAuth
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        email = findViewById(R.id.login_email)
        pass = findViewById(R.id.login_password)
        fAuth = FirebaseAuth.getInstance()
        progressBar = findViewById(R.id.pgBar)
    }

    fun login(view: View){
        progressBar.visibility = View.VISIBLE
        val email_id=email.text.toString().trim()
        val password =pass.text.toString().trim()
        if(TextUtils.isEmpty(email_id)){
            email.error = "Email is required"
            return
        }
        if(TextUtils.isEmpty(password)){
            pass.error = "Password is required"
            return
        }
        fAuth.signInWithEmailAndPassword(email_id,password).addOnCompleteListener {
            if(it.isSuccessful)
            {
                Toast.makeText(this,"Log in successful",Toast.LENGTH_SHORT).show()
            }
            else {
                Toast.makeText(this, "Error! " + it.exception?.message, Toast.LENGTH_SHORT).show()
                progressBar.visibility = View.INVISIBLE

            }
        }

    }

    fun register(view: View){
        val intent = Intent(this@LoginActivity,SignupActivity::class.java)
        startActivity(intent)
    }
}