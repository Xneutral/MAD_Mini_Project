package com.example.assignment

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.view.View
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth

class SignupActivity : AppCompatActivity() {

    private lateinit var email:EditText
    private lateinit var pass:EditText
    private lateinit var cPass:EditText
    private lateinit var fAuth:FirebaseAuth
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)
        fAuth = FirebaseAuth.getInstance()
        email = findViewById(R.id.email)
        pass = findViewById(R.id.password)
        cPass = findViewById(R.id.c_password)
    }

    fun signup(view: View)
    {
        val email_id=email.text.toString().trim()
        val passcode = pass.text.toString().trim()
        val cPasscode = cPass.text.toString().trim()
        if(TextUtils.isEmpty(email_id)){
            email.error = "Email is required"
            }
        if(TextUtils.isEmpty(passcode)){
            pass.error = "Password is required"
        }
        if(passcode.length < 6)
            pass.error = "Password must be more than 6 characters"
        if(passcode!=cPasscode)
            Toast.makeText(this, "Password doesn't match",Toast.LENGTH_SHORT).show()
        else
        {
            fAuth.createUserWithEmailAndPassword(email_id,passcode).addOnCompleteListener {
                if (it.isSuccessful) {
                    Toast.makeText(this, "User created>>>>>. ", Toast.LENGTH_SHORT).show()
                }
                else {
                    Toast.makeText(this, "Error! " + it.exception?.message, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    fun login_click(view: View)
    {
        val intent = Intent(this@SignupActivity,LoginActivity::class.java)
        startActivity(intent)
    }

}
